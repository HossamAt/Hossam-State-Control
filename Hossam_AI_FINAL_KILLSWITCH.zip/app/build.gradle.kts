import java.net.URI

plugins {
    id("com.android.application")
    kotlin("android")
}

android {
    namespace = "com.nova.discordpresence"
    compileSdk = 35
    ndkVersion = "27.3.13750724"

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    val githubRepository = "HossamAt/Hossam-AI-Control"

    defaultConfig {
        applicationId = "com.nova.discordpresence"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "2.3"
        buildConfigField(
            "String",
            "KILL_SWITCH_URL",
            "\"https://raw.githubusercontent.com/$githubRepository/main/kill_switch.json\""
        )

        externalNativeBuild {
            cmake { cppFlags += "-std=c++17" }
        }
        ndk { abiFilters += "arm64-v8a" }
    }

    buildFeatures {
        prefab = true
        buildConfig = true
    }

    externalNativeBuild {
        cmake { path = file("src/main/cpp/CMakeLists.txt") }
    }
}

val downloadBrandAssets by tasks.registering {
    val resDir = layout.projectDirectory.dir("src/main/res/drawable").asFile
    outputs.files(
        resDir.resolve("discord_icon.png"),
        resDir.resolve("app_background.png")
    )
    doLast {
        fun download(url: String, target: java.io.File) {
            target.parentFile.mkdirs()
            URI(url).toURL().openStream().use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            }
            if (!target.exists() || target.length() < 100) {
                throw GradleException("Failed to download brand asset: $url")
            }
        }

        download("https://f.top4top.io/p_3912j0e5m0.png", resDir.resolve("discord_icon.png"))
        download("https://i.top4top.io/p_3912qg0g10.png", resDir.resolve("app_background.png"))
    }
}

tasks.named("preBuild") { dependsOn(downloadBrandAssets) }

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("io.coil-kt:coil:2.7.0")
    implementation(files("libs/discord_partner_sdk.aar"))
}
