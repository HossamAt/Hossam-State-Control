package com.nova.discordpresence

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator

class PresenceToggle @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val thumbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var progress = 0f
    private var checked = false
    private var downX = 0f
    private var dragging = false
    var onCheckedChange: ((Boolean) -> Unit)? = null

    init {
        isClickable = true
        trackPaint.color = 0x9959616D.toInt()
        thumbPaint.color = 0xFFF1EEE8.toInt()
        contentDescription = "الاتصال"
    }

    fun setChecked(value: Boolean, animate: Boolean = true) {
        checked = value
        if (!animate) {
            progress = if (value) 1f else 0f
            invalidate()
            return
        }
        ValueAnimator.ofFloat(progress, if (value) 1f else 0f).apply {
            duration = 180
            interpolator = DecelerateInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun isChecked(): Boolean = checked

    private fun commit(value: Boolean) {
        if (checked == value) return
        checked = value
        onCheckedChange?.invoke(value)
        setChecked(value, true)
        performClick()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (kotlin.math.abs(event.x - downX) > 8f) dragging = true
                if (dragging) {
                    val left = paddingLeft.toFloat()
                    val right = width - paddingRight.toFloat()
                    val usable = (right - left - height * 0.72f).coerceAtLeast(1f)
                    progress = ((event.x - left - height * 0.36f) / usable).coerceIn(0f, 1f)
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    commit(progress >= 0.5f)
                } else {
                    commit(!checked)
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                setChecked(checked, true)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val h = height.toFloat()
        val w = width.toFloat()
        val radius = h * 0.5f
        trackPaint.color = if (progress > 0.01f) 0xCC57D38A.toInt() else 0xAA59616D.toInt()
        val track = RectF(0f, h * 0.18f, w, h * 0.82f)
        canvas.drawRoundRect(track, radius, radius, trackPaint)

        thumbPaint.color = if (progress > 0.01f) 0xFFF7F4EF.toInt() else 0xFFE0E4E7.toInt()
        val thumbR = h * 0.30f
        val minX = h * 0.36f
        val maxX = w - h * 0.36f
        val cx = minX + (maxX - minX) * progress
        canvas.drawCircle(cx, h * 0.5f, thumbR, thumbPaint)
    }
}
