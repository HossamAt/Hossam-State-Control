package com.nova.discordpresence

object NativeBridge {
    init {
        System.loadLibrary("nova_presence")
    }

    external fun init(context: android.content.Context, applicationId: Long): Boolean

    external fun runCallbacks()

    external fun reinitialize(applicationId: Long): Boolean

    external fun startPresence(
        name: String,
        details: String,
        state: String,
        largeImage: String,
        largeText: String,
        smallImage: String,
        smallText: String,
        startEpoch: Long
    ): Boolean

    external fun stopPresence()
    external fun shutdown()

    @Volatile
    var lastEventSequence: Long = 0L
        private set

    @Volatile
    var lastEventType: String = ""
        private set

    @Volatile
    var lastEventMessage: String = ""
        private set

    @Volatile
    var lastSuccessAtMillis: Long = 0L
        private set

    @JvmStatic
    fun onNativeEvent(type: String, message: String) {
        lastEventType = type
        lastEventMessage = message
        lastEventSequence += 1L
        if (type == "PRESENCE_OK") {
            lastSuccessAtMillis = System.currentTimeMillis()
        }
        MainActivity.lastStatus = "$type: $message"
    }
}
