package com.nova.discordpresence

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper

/**
 * Owns the complete Rich Presence lifecycle.
 * The Activity only sends configuration to this service.
 */
class PresenceService : Service() {

    data class Config(
        val name: String,
        val details: String,
        val state: String,
        val largeImage: String,
        val largeText: String,
        val smallImage: String,
        val smallText: String,
        val startEpoch: Long
    )

    companion object {
        const val ACTION_UPDATE = "com.nova.discordpresence.UPDATE"
        const val ACTION_STOP = "com.nova.discordpresence.STOP"

        private const val PREFS = "presence_service"
        private const val KEY_ACTIVE = "active"
        private const val APP_ID = 1549333944686612570L
        private const val NOTIFICATION_ID = 77

        @Volatile
        var currentConfig: Config? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private var sdkReady = false
    private var stoppedByUser = false
    private var lastHandledNativeEvent = 0L
    private var consecutiveFailures = 0

    private val pendingPresenceUpdate = Runnable { currentConfig?.let { sendPresence(it) } }
    private val restorePresenceUpdate = Runnable { currentConfig?.let { sendPresence(it) } }

    /** Run the SDK callback pump on Android's main looper. */
    private val callbackPump = object : Runnable {
        override fun run() {
            if (stoppedByUser) return
            try {
                NativeBridge.runCallbacks()
            } catch (_: Throwable) {
                // Never let the SDK callback-pump problem kill the foreground service.
            }
            handler.postDelayed(this, 50L)
        }
    }

    /**
     * Keep the activity alive even if Discord silently drops a direct-RPC update.
     * Two minutes keeps the Android direct-RPC session fresh without spamming updates. The original startEpoch is always reused.
     */
    private val presenceHeartbeat = object : Runnable {
        override fun run() {
            if (stoppedByUser) return
            currentConfig?.let { sendPresence(it) }
            handler.postDelayed(this, 2 * 60_000L)
        }
    }

    /**
     * React quickly to an SDK error and recreate the native Client only when the
     * SDK actually reports a failed operation. This is the important recovery
     * path for long-running Android direct-RPC sessions.
     */
    private val healthCheck = object : Runnable {
        override fun run() {
            if (stoppedByUser) return

            val sequence = NativeBridge.lastEventSequence
            if (sequence != lastHandledNativeEvent) {
                lastHandledNativeEvent = sequence
                if (NativeBridge.lastEventType == "PRESENCE_ERROR") {
                    consecutiveFailures++
                    scheduleRecovery()
                } else if (NativeBridge.lastEventType == "PRESENCE_OK") {
                    consecutiveFailures = 0
                }
            }

            handler.postDelayed(this, 2_000L)
        }
    }

    /**
     * Some transport failures can be silent (no failed callback is delivered).
     * If we have an active presence but have not received a successful update for
     * a while, rebuild the client and publish the saved activity again. This keeps
     * the recovery path working even when the RPC pipe dies without an error event.
     */
    private val silentDisconnectWatchdog = object : Runnable {
        override fun run() {
            if (!stoppedByUser && currentConfig != null) {
                val lastOk = NativeBridge.lastSuccessAtMillis
                val now = System.currentTimeMillis()
                val stale = lastOk == 0L || now - lastOk > 75_000L
                if (stale) {
                    recoverFromSilentDisconnect()
                }
            }
            handler.postDelayed(this, 30_000L)
        }
    }

    /**
     * Remote master switch. Existing installed copies periodically check this
     * file. If disabled, Discord Rich Presence is cleared and the service exits.
     */
    private var killSwitchLastEnabled: Boolean? = null

private val killSwitchCheck: Runnable = object : Runnable {
        override fun run() {
            if (stoppedByUser) return
            KillSwitch.checkAsync(this@PresenceService) { state ->
                if (!state.enabled) {
                    stopPresenceByUser()
                    return@checkAsync
                }
                handler.postDelayed(killSwitchCheck, 30_000L)
            }
        }
    }

    override fun onCreate() {
        super.onCreate()

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        restoreConfig()

        handler.post(callbackPump)
        handler.post(healthCheck)
        handler.post(silentDisconnectWatchdog)
        handler.post(killSwitchCheck)

        // Check the master switch before restoring a previously active presence.
        KillSwitch.checkAsync(this) { state ->
            if (!state.enabled) {
                stopPresenceByUser()
                return@checkAsync
            }

            sdkReady = initSdk()
            if (sdkReady && currentConfig != null) {
                handler.postDelayed(restorePresenceUpdate, 700L)
            }

            // Periodic heartbeat prevents a long-lived direct-RPC session from going
            // stale. It does NOT change the displayed timer because startEpoch is kept.
            handler.postDelayed(presenceHeartbeat, 2 * 60_000L)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopPresenceByUser()
            ACTION_UPDATE -> {
                val updateIntent = intent
                KillSwitch.checkAsync(this) { state ->
                    if (!state.enabled) {
                        stopPresenceByUser()
                        return@checkAsync
                    }
                    applyPresenceUpdate(updateIntent)
                }
            }
        }

        return START_STICKY
    }

    private fun applyPresenceUpdate(intent: Intent) {
        stoppedByUser = false

        val name = intent.getStringExtra("name") ?: "OneState"
        val details = intent.getStringExtra("details") ?: "Server : Fortuna ME"
        val state = intent.getStringExtra("state") ?: "by Hossamat"
        val largeImage = intent.getStringExtra("largeImage") ?: ""
        val largeText = intent.getStringExtra("largeText") ?: ""
        val smallImage = intent.getStringExtra("smallImage") ?: ""
        val smallText = intent.getStringExtra("smallText") ?: ""
        val requestedStartEpoch =
            intent.getLongExtra("startEpoch", System.currentTimeMillis() / 1000L)
        val forceReset = intent.getBooleanExtra("forceReset", false)

        // Reuse the active timestamp when reconnecting the same server.
        // When the previous session was manually disconnected, resume from
        // the exact elapsed time saved by stopPresenceByUser().
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val hasSavedSession = prefs.getBoolean(KEY_ACTIVE, false)
        val savedServer = prefs.getString("largeText", null)
        val savedStartEpoch = prefs.getLong("startEpoch", 0L)
        val pausedElapsedKey = pausedElapsedKey(largeText)
        val pausedElapsed = prefs.getLong(pausedElapsedKey, -1L)
        val legacyPausedServer = prefs.getString("pausedServer", null)
        val legacyPausedElapsed = prefs.getLong("pausedElapsed", 0L).coerceAtLeast(0L)

        val startEpoch = when {
            !forceReset && hasSavedSession && savedServer == largeText && savedStartEpoch > 0L -> savedStartEpoch
            !forceReset && pausedElapsed >= 0L -> System.currentTimeMillis() / 1000L - pausedElapsed
            !forceReset && legacyPausedServer == largeText -> System.currentTimeMillis() / 1000L - legacyPausedElapsed
            else -> requestedStartEpoch
        }

        val config = Config(
            name, details, state, largeImage, largeText, smallImage, smallText, startEpoch
        )

        currentConfig = config
        saveConfig(config)

        if (!sdkReady) sdkReady = initSdk()

        handler.removeCallbacks(restorePresenceUpdate)
        handler.removeCallbacks(pendingPresenceUpdate)
        handler.postDelayed(pendingPresenceUpdate, 250L)
    }

    private fun initSdk(): Boolean {
        return try {
            NativeBridge.init(this, APP_ID)
        } catch (_: Throwable) {
            false
        }
    }

    private var lastSilentRecoveryAt = 0L

    private fun recoverFromSilentDisconnect() {
        if (stoppedByUser || currentConfig == null) return
        val now = System.currentTimeMillis()
        if (now - lastSilentRecoveryAt < 20_000L) return
        lastSilentRecoveryAt = now

        try {
            val rebuilt = NativeBridge.reinitialize(APP_ID)
            sdkReady = rebuilt
            consecutiveFailures = 0
            if (rebuilt) currentConfig?.let { sendPresence(it) }
        } catch (_: Throwable) {
            sdkReady = false
            consecutiveFailures++
            scheduleRecovery()
        }
    }

    private fun scheduleRecovery() {
        if (stoppedByUser || currentConfig == null) return

        handler.removeCallbacks(recoveryRunnable)
        // Short retry after an error; avoid a tight reconnect loop.
        handler.postDelayed(recoveryRunnable, if (consecutiveFailures >= 3) 1_500L else 750L)
    }

    private val recoveryRunnable = Runnable {
        if (stoppedByUser || currentConfig == null) return@Runnable

        // After repeated failures, rebuild the native Client. The old request has
        // already completed with an error at this point, so this is safe and gives
        // the Android RPC transport a clean object to work with.
        if (consecutiveFailures >= 3) {
            try {
                NativeBridge.reinitialize(APP_ID)
                sdkReady = true
            } catch (_: Throwable) {
                sdkReady = false
            }
            consecutiveFailures = 0
        } else if (!sdkReady) {
            sdkReady = initSdk()
        }

        currentConfig?.let { sendPresence(it) }
    }

    private fun sendPresence(config: Config) {
        if (stoppedByUser) return
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        if (prefs.getBoolean("remote_disabled", false)) return

        if (!sdkReady) {
            sdkReady = initSdk()
        }
        if (!sdkReady) return

        try {
            val queued = NativeBridge.startPresence(
                config.name,
                config.details,
                config.state,
                config.largeImage,
                config.largeText,
                config.smallImage,
                config.smallText,
                config.startEpoch
            )
            if (!queued) {
                consecutiveFailures++
                scheduleRecovery()
            }
        } catch (_: Throwable) {
            consecutiveFailures++
            scheduleRecovery()
        }
    }

    private fun pausedElapsedKey(serverName: String): String =
        "pausedElapsed::" + serverName

    private fun stopPresenceByUser() {
        // Important: keep the service and SDK callback pump alive while Discord
        // receives ClearRichPresence. Stopping the service immediately after
        // queuing the clear request can leave the old activity visible.
        stoppedByUser = true

        val configToStop = currentConfig
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)

        configToStop?.let { config ->
            val now = System.currentTimeMillis() / 1000L
            val elapsed = (now - config.startEpoch).coerceAtLeast(0L)
            prefs.edit()
                .putBoolean(KEY_ACTIVE, false)
                .putString("pausedServer", config.largeText)
                .putLong("pausedElapsed", elapsed)
                .putLong(pausedElapsedKey(config.largeText), elapsed)
                .apply()
        } ?: prefs.edit().putBoolean(KEY_ACTIVE, false).apply()

        currentConfig = null
        handler.removeCallbacksAndMessages(null)

        try {
            if (sdkReady) {
                NativeBridge.stopPresence()
            }
        } catch (_: Throwable) {
            // Explicit stop should never crash the app.
        }

        sdkReady = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            "presence",
            "Hossam State",
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        return Notification.Builder(this, "presence")
            .setContentTitle("Hossam State")
            .setContentText("OneState • Rich Presence يعمل بالخلفية")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    private fun saveConfig(c: Config) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean(KEY_ACTIVE, true)
            .putString("name", c.name)
            .putString("details", c.details)
            .putString("state", c.state)
            .putString("largeImage", c.largeImage)
            .putString("largeText", c.largeText)
            .putString("smallImage", c.smallImage)
            .putString("smallText", c.smallText)
            .putLong("startEpoch", c.startEpoch)
            .apply()

        // The live session is authoritative now; the paused snapshot will be
        // overwritten on the next manual disconnect.
    }

    private fun restoreConfig() {
        val p = getSharedPreferences(PREFS, MODE_PRIVATE)
        if (!p.getBoolean(KEY_ACTIVE, false)) return

        currentConfig = Config(
            p.getString("name", "OneState") ?: "OneState",
            p.getString("details", "Server : Fortuna ME") ?: "Server : Fortuna ME",
            p.getString("state", "by Hossamat") ?: "by Hossamat",
            p.getString("largeImage", "") ?: "",
            p.getString("largeText", "") ?: "",
            p.getString("smallImage", "") ?: "",
            p.getString("smallText", "") ?: "",
            p.getLong("startEpoch", System.currentTimeMillis() / 1000L)
        )
    }

    private fun clearSavedConfig() {
        // Legacy helper: clear only the live-session flag. The paused timer
        // snapshot must remain available for the next reconnect.
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putBoolean(KEY_ACTIVE, false)
            .apply()
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // The service is independent from the Activity task. Because the service
        // is foreground and stopWithTask=false, removing the app from Recents
        // must not stop or recreate it here. START_STICKY is the OS-level fallback
        // if Android later reclaims the process.
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        // Do not clear the native client here. Android can destroy/recreate a
        // started service and START_STICKY should be able to recover cleanly.
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
