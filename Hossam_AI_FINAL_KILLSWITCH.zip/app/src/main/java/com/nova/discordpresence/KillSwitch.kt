package com.nova.discordpresence

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Remote Kill Switch for Hossam State.
 *
 * enabled = true  -> التطبيق يعمل
 * enabled = false -> التطبيق مقفل
 *
 * القفل مستقل عن النسخة القديمة.
 */
object KillSwitch {

    private const val CONTROL_URL =
        "https://raw.githubusercontent.com/HossamAt/Hossam-AI-Control/main/kill_switch.json"

    data class State(
        val enabled: Boolean,
        val message: String
    )

    private val executor = Executors.newSingleThreadExecutor()

    fun checkAsync(
        context: Context,
        callback: (State) -> Unit
    ) {
        executor.execute {
            val state = fetch()

            Handler(Looper.getMainLooper()).post {
                context.getSharedPreferences(
                    "presence_service",
                    Context.MODE_PRIVATE
                ).edit()
                    .putBoolean("remote_disabled", !state.enabled)
                    .putString("remote_disable_message", state.message)
                    .apply()

                callback(state)
            }
        }
    }

    fun fetch(): State {
        var connection: HttpURLConnection? = null

        return try {
            connection =
                (URL(
                    CONTROL_URL + "?t=" + System.currentTimeMillis()
                ).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 10_000
                    readTimeout = 10_000
                    useCaches = false

                    setRequestProperty("Cache-Control", "no-cache")
                    setRequestProperty("Pragma", "no-cache")
                }

            if (connection.responseCode !in 200..299) {
                return State(
                    false,
                    "تعذر التحقق من حالة التطبيق."
                )
            }

            val body =
                BufferedReader(
                    InputStreamReader(
                        connection.inputStream,
                        Charsets.UTF_8
                    )
                ).use { reader ->
                    buildString {
                        reader.forEachLine { append(it) }
                    }
                }

            val enabledMatch = Regex(
                "\"enabled\"\\s*:\\s*(true|false)",
                RegexOption.IGNORE_CASE
            ).find(body)

            val messageMatch = Regex(
                "\"message\"\\s*:\\s*\"([^\"]*)\""
            ).find(body)

            val enabled =
                enabledMatch
                    ?.groupValues
                    ?.getOrNull(1)
                    ?.equals("true", ignoreCase = true)
                    ?: false

            val message =
                messageMatch
                    ?.groupValues
                    ?.getOrNull(1)
                    ?.trim()
                    .orEmpty()
                    .ifEmpty { "التطبيق متوقف حاليًا." }

            State(enabled, message)

        } catch (_: Throwable) {
            // Fail CLOSED: no verification = no app usage.
            State(
                false,
                "تعذر التحقق من حالة التطبيق."
            )
        } finally {
            connection?.disconnect()
        }
    }
}
