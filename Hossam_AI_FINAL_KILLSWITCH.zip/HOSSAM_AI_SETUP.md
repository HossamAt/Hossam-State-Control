# Hossam AI — V3 connected setup

## Android ↔ Backend contract
The Android app sends:
`POST /chat`
with:
`{"message":"..."}`

The backend returns:
`{"answer":"..."}`

The Android client also accepts `{"reply":"..."}` and plain text, so a mismatched response will not show the old generic “وصل رد غير مفهوم من الخادم” message.

## Backend
Deploy the `backend` folder as the service behind:
`https://hossam-ai-backend.onrender.com/chat`

Set:
- `GEMINI_API_KEY` = your provider API key
- optional `GEMINI_MODEL` = model name

Never put the API key in the Android project.
